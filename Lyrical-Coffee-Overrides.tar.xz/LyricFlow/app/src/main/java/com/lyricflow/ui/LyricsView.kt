package com.lyricflow.ui

import android.graphics.BitmapFactory
import android.os.Build
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.FiniteAnimationSpec
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.snap
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.matchParentSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.material3.ColorScheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.blur
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shadow
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.onSizeChanged
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.lyricflow.data.Align
import com.lyricflow.data.AnimStyle
import com.lyricflow.data.BgMode
import com.lyricflow.data.FontChoice
import com.lyricflow.data.LrcLine
import com.lyricflow.data.LyricSettings
import com.lyricflow.data.Presets
import com.lyricflow.data.indexAt
import com.lyricflow.text.LyricText
import kotlin.math.roundToInt

data class LyricColors(val text: Color, val accent: Color)

@Composable
fun rememberDynamicScheme(): ColorScheme? {
    val ctx = LocalContext.current
    return remember { if (Build.VERSION.SDK_INT >= 31) dynamicDarkColorScheme(ctx) else null }
}

fun resolveColors(s: LyricSettings, dyn: ColorScheme?): LyricColors = when (s.bgMode) {
    BgMode.SYSTEM -> LyricColors(dyn?.onSurface ?: Color(0xFF38251D), dyn?.primary ?: Color(0xFF765039))
    BgMode.ICE -> LyricColors(Color(0xFF243944), Color(0xFF24627A))
    else -> LyricColors(Color(s.textColor), Color(s.accentColor))
}

/** The background the user designed: system colour, solid, gradient, album art or their own photo. */
@Composable
fun LyricBackground(
    s: LyricSettings,
    modifier: Modifier = Modifier,
    shape: Shape = MaterialTheme.shapes.large,
    art: android.graphics.Bitmap? = null,
    content: @Composable BoxScope.() -> Unit,
) {
    val dyn = rememberDynamicScheme()
    val a = s.bgOpacity
    val scrim = Color.Black.copy(alpha = 0.45f)
    Box(modifier.clip(shape)) {
        val gradient = Presets.gradients[s.gradientIndex.coerceIn(Presets.gradients.indices)]
        when (s.bgMode) {
            BgMode.SYSTEM ->
                Box(Modifier.matchParentSize().background((dyn ?: MaterialTheme.colorScheme).surfaceVariant))
            BgMode.COFFEE -> {
                Box(Modifier.matchParentSize().background(Brush.linearGradient(listOf(Color(0xFF38251D), Color(0xFF765039), Color(0xFFC18A5A))), alpha = a))
                Box(Modifier.matchParentSize().background(Color(0xFF211713).copy(alpha = 0.10f)))
            }
            BgMode.ICE -> {
                Box(Modifier.matchParentSize().background(Brush.linearGradient(listOf(Color(0xFFE5F5F8), Color(0xFFB9DCE5), Color(0xFF7EAAB9))), alpha = a))
                Box(Modifier.matchParentSize().background(Color.White.copy(alpha = 0.16f)))
            }
            BgMode.GLASS -> {
                Box(Modifier.matchParentSize().background(Brush.linearGradient(listOf(Color(0xFF211B18), Color(0xFF514137), Color(0xFF2C241F))), alpha = a))
                Box(Modifier.matchParentSize().background(Color(0xFF211713).copy(alpha = 0.22f)))
            }
            BgMode.SOLID ->
                Box(Modifier.matchParentSize().background(Color(s.solidColor).copy(alpha = a)))
            BgMode.ALBUM_ART -> {
                if (art != null) {
                    Image(art.asImageBitmap(), null, Modifier.matchParentSize().blur(36.dp), contentScale = ContentScale.Crop, alpha = a)
                    Box(Modifier.matchParentSize().background(scrim))
                } else Box(Modifier.matchParentSize().background(Brush.linearGradient(gradient.colors.map { Color(it) }), alpha = a))
            }
            BgMode.IMAGE -> {
                val bmp = remember(s.imagePath) { s.imagePath?.let { BitmapFactory.decodeFile(it)?.asImageBitmap() } }
                if (bmp != null) {
                    Image(bmp, null, Modifier.matchParentSize(), contentScale = ContentScale.Crop, alpha = a)
                    Box(Modifier.matchParentSize().background(scrim))
                } else Box(Modifier.matchParentSize().background(Brush.linearGradient(gradient.colors.map { Color(it) }), alpha = a))
            }
            BgMode.GRADIENT ->
                Box(Modifier.matchParentSize().background(Brush.linearGradient(gradient.colors.map { Color(it) }), alpha = a))
        }
        content()
    }
}

/** Auto-scrolling lyrics. The line that is playing animates in the chosen style. */
@Composable
fun LyricsList(
    lines: List<LrcLine>,
    posMs: Long,
    s: LyricSettings,
    colors: LyricColors,
    modifier: Modifier = Modifier,
    scrollable: Boolean = true,
) {
    val shown = remember(lines, s.scriptMode) { lines.map { LyricText.prepare(s.scriptMode, it.text) } }
    val pos = posMs + s.syncOffsetMs
    val idx = lines.indexAt(pos)
    val state = rememberLazyListState()
    var viewportH by remember { mutableIntStateOf(0) }
    val density = LocalDensity.current

    LaunchedEffect(idx, lines) {
        if (lines.isEmpty()) return@LaunchedEffect
        val target = idx.coerceAtLeast(0)
        if (s.animStyle == AnimStyle.NONE) state.scrollToItem(target) else state.animateScrollToItem(target)
    }

    val hAlign = when (s.align) {
        Align.START -> Alignment.Start
        Align.CENTER -> Alignment.CenterHorizontally
        Align.END -> Alignment.End
    }
    LazyColumn(
        state = state,
        userScrollEnabled = scrollable,
        modifier = modifier.onSizeChanged { viewportH = it.height },
        horizontalAlignment = hAlign,
        contentPadding = PaddingValues(
            start = 20.dp, end = 20.dp,
            top = with(density) { (viewportH / 3).toDp() },
            bottom = with(density) { (viewportH * 2 / 3).toDp() },
        ),
    ) {
        itemsIndexed(lines) { i, line ->
            val active = i == idx
            val progress = if (active) {
                val end = lines.getOrNull(i + 1)?.timeMs ?: (line.timeMs + 4000)
                ((pos - line.timeMs).toFloat() / (end - line.timeMs).coerceAtLeast(1)).coerceIn(0f, 1f)
            } else 0f
            LyricLine(shown[i].first, shown[i].second, active, progress, s, colors)
        }
    }
}

@Composable
fun LyricLine(main: String, sub: String?, active: Boolean, progress: Float, s: LyricSettings, c: LyricColors) {
    val style = s.animStyle
    val ms = (420 / s.animSpeed).toInt().coerceAtLeast(60)
    val spec: FiniteAnimationSpec<Float> =
        if (style == AnimStyle.NONE) snap() else tween(ms, easing = FastOutSlowInEasing)
    val a by animateFloatAsState(if (active) 1f else 0f, spec, label = "active")

    val pulse = if (style == AnimStyle.GLOW) {
        rememberInfiniteTransition(label = "glow").animateFloat(
            initialValue = 0f,
            targetValue = 1f,
            animationSpec = infiniteRepeatable(
                tween((1400 / s.animSpeed).toInt().coerceAtLeast(200), easing = LinearEasing),
                RepeatMode.Reverse,
            ),
            label = "pulse",
        ).value
    } else 0f

    val sizeSp = 24f * s.fontScale
    val lineAlpha = if (style == AnimStyle.NONE) (if (active) 1f else 0.4f) else 0.38f + 0.62f * a
    val lineScale = if (style == AnimStyle.ZOOM) 0.9f + 0.14f * a else 1f
    val dens = LocalDensity.current.density
    val lineDy = if (style == AnimStyle.SLIDE) (1f - a) * 28f * dens else 0f
    val origin = TransformOrigin(when (s.align) { Align.START -> 0f; Align.CENTER -> 0.5f; Align.END -> 1f }, 0.5f)
    val textAlign = when (s.align) { Align.START -> TextAlign.Start; Align.CENTER -> TextAlign.Center; Align.END -> TextAlign.End }
    val family = when (s.font) {
        FontChoice.SANS -> FontFamily.SansSerif
        FontChoice.SERIF -> FontFamily.Serif
        FontChoice.MONO -> FontFamily.Monospace
        FontChoice.CURSIVE -> FontFamily.Cursive
    }
    val base = if (active && style != AnimStyle.KARAOKE) c.accent else c.text
    val codePoints = main.codePointCount(0, main.length)
    val revealCount = (codePoints * progress).roundToInt().coerceIn(0, codePoints)
    val revealEnd = main.offsetByCodePoints(0, revealCount)
    val typewriterCount = (codePoints * progress * 1.25f).roundToInt().coerceIn(0, codePoints)
    val typewriterEnd = main.offsetByCodePoints(0, typewriterCount)
    val body = buildAnnotatedString {
        if (active && style == AnimStyle.TYPEWRITER) {
            append(main.substring(0, typewriterEnd))
            val cursorStart = length
            if (typewriterEnd < main.length) append("▏")
            if (length > cursorStart) addStyle(SpanStyle(color = c.accent), cursorStart, length)
            val hiddenStart = length
            append(main.substring(typewriterEnd))
            if (length > hiddenStart) addStyle(SpanStyle(color = Color.Transparent), hiddenStart, length)
        } else {
            append(main)
            if (active && style == AnimStyle.KARAOKE) {
                addStyle(SpanStyle(color = c.accent), 0, revealEnd)
                addStyle(SpanStyle(color = c.text.copy(alpha = 0.75f)), revealEnd, main.length)
            }
        }
    }
    val glow = if (style == AnimStyle.GLOW && active)
        Shadow(color = c.accent.copy(alpha = 0.9f), blurRadius = 10f + 28f * pulse) else null

    Column(
        Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .graphicsLayer {
                this.alpha = lineAlpha
                scaleX = lineScale
                scaleY = lineScale
                translationY = lineDy
                transformOrigin = origin
            },
        horizontalAlignment = when (s.align) {
            Align.START -> Alignment.Start
            Align.CENTER -> Alignment.CenterHorizontally
            Align.END -> Alignment.End
        },
    ) {
        Text(
            text = body,
            color = base,
            fontSize = sizeSp.sp,
            lineHeight = (sizeSp * 1.3f).sp,
            fontWeight = if (s.bold) FontWeight.Bold else FontWeight.Normal,
            fontStyle = if (s.italic) FontStyle.Italic else FontStyle.Normal,
            fontFamily = family,
            textAlign = textAlign,
            style = TextStyle(shadow = glow),
            modifier = Modifier.fillMaxWidth(),
        )
        if (sub != null) {
            Text(
                text = sub,
                color = c.text.copy(alpha = 0.6f),
                fontSize = (sizeSp * 0.6f).sp,
                fontStyle = FontStyle.Italic,
                textAlign = textAlign,
                modifier = Modifier.fillMaxWidth(),
            )
        }
    }
}
