package com.lyricflow.data

import android.content.Context
import androidx.datastore.preferences.core.MutablePreferences
import androidx.datastore.preferences.core.Preferences
import androidx.datastore.preferences.core.booleanPreferencesKey
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.floatPreferencesKey
import androidx.datastore.preferences.core.intPreferencesKey
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.store by preferencesDataStore("lyricflow_settings")

object SettingsRepo {
    private val kBg = stringPreferencesKey("bg")
    private val kSolid = intPreferencesKey("solid")
    private val kGrad = intPreferencesKey("grad")
    private val kImg = stringPreferencesKey("img")
    private val kBgAlpha = floatPreferencesKey("bgAlpha")
    private val kText = intPreferencesKey("text")
    private val kAccent = intPreferencesKey("accent")
    private val kFont = stringPreferencesKey("font")
    private val kScale = floatPreferencesKey("scale")
    private val kBold = booleanPreferencesKey("bold")
    private val kItalic = booleanPreferencesKey("italic")
    private val kAlign = stringPreferencesKey("align")
    private val kRadius = intPreferencesKey("radius")
    private val kAround = intPreferencesKey("around")
    private val kInfo = booleanPreferencesKey("info")
    private val kAnim = stringPreferencesKey("anim")
    private val kSpeed = floatPreferencesKey("speed")
    private val kScript = stringPreferencesKey("script")
    private val kOffset = intPreferencesKey("offset")

    private inline fun <reified E : Enum<E>> Preferences.pick(k: Preferences.Key<String>, d: E): E =
        this[k]?.let { n -> enumValues<E>().firstOrNull { it.name == n } } ?: d

    private fun read(p: Preferences): LyricSettings {
        val d = LyricSettings()
        return LyricSettings(
            bgMode = p.pick(kBg, d.bgMode),
            solidColor = (p[kSolid] ?: d.solidColor).let { if (it == 0xFF1B1033.toInt()) d.solidColor else it },
            gradientIndex = p[kGrad] ?: d.gradientIndex,
            imagePath = p[kImg],
            bgOpacity = p[kBgAlpha] ?: d.bgOpacity,
            textColor = (p[kText] ?: d.textColor).let { if (it == 0xFFFFFFFF.toInt()) d.textColor else it },
            accentColor = (p[kAccent] ?: d.accentColor).let { if (it == 0xFFFF6FD8.toInt()) d.accentColor else it },
            font = p.pick(kFont, d.font),
            fontScale = p[kScale] ?: d.fontScale,
            bold = p[kBold] ?: d.bold,
            italic = p[kItalic] ?: d.italic,
            align = p.pick(kAlign, d.align),
            cornerRadius = p[kRadius] ?: d.cornerRadius,
            linesAround = p[kAround] ?: d.linesAround,
            showTrackInfo = p[kInfo] ?: d.showTrackInfo,
            animStyle = p.pick(kAnim, d.animStyle),
            animSpeed = p[kSpeed] ?: d.animSpeed,
            scriptMode = p.pick(kScript, d.scriptMode),
            syncOffsetMs = p[kOffset] ?: d.syncOffsetMs,
        )
    }

    private fun write(p: MutablePreferences, s: LyricSettings) {
        p[kBg] = s.bgMode.name
        p[kSolid] = s.solidColor
        p[kGrad] = s.gradientIndex
        val path = s.imagePath
        if (path != null) p[kImg] = path else p.remove(kImg)
        p[kBgAlpha] = s.bgOpacity
        p[kText] = s.textColor
        p[kAccent] = s.accentColor
        p[kFont] = s.font.name
        p[kScale] = s.fontScale
        p[kBold] = s.bold
        p[kItalic] = s.italic
        p[kAlign] = s.align.name
        p[kRadius] = s.cornerRadius
        p[kAround] = s.linesAround
        p[kInfo] = s.showTrackInfo
        p[kAnim] = s.animStyle.name
        p[kSpeed] = s.animSpeed
        p[kScript] = s.scriptMode.name
        p[kOffset] = s.syncOffsetMs
    }

    fun flow(ctx: Context): Flow<LyricSettings> = ctx.store.data.map { read(it) }

    suspend fun update(ctx: Context, change: (LyricSettings) -> LyricSettings) {
        ctx.store.edit { p -> write(p, change(read(p))) }
    }
}
