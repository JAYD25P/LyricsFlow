package com.lyricflow.data

enum class BgMode(val label: String) {
    SYSTEM("System colours"), COFFEE("Coffee"), ICE("Ice"), GLASS("Glass"), SOLID("Solid"), GRADIENT("Gradient"), ALBUM_ART("Album art"), IMAGE("My photo")
}

enum class AnimStyle(val label: String) {
    NONE("None"), FADE("Fade"), SLIDE("Slide up"), ZOOM("Zoom"),
    KARAOKE("Karaoke fill"), TYPEWRITER("Typewriter"), GLOW("Glow pulse")
}

enum class ScriptMode(val label: String) {
    ORIGINAL("Original"), HINGLISH("Hinglish / Roman"), BOTH("Both")
}

enum class FontChoice(val label: String) { SANS("Sans"), SERIF("Serif"), MONO("Mono"), CURSIVE("Cursive") }

enum class Align(val label: String) { START("Left"), CENTER("Centre"), END("Right") }

data class LrcLine(val timeMs: Long, val text: String)

/** Index of the line that is active at [posMs]; -1 before the first line. */
fun List<LrcLine>.indexAt(posMs: Long): Int {
    var lo = 0
    var hi = size - 1
    var ans = -1
    while (lo <= hi) {
        val mid = (lo + hi) ushr 1
        if (this[mid].timeMs <= posMs) { ans = mid; lo = mid + 1 } else hi = mid - 1
    }
    return ans
}

data class LyricSettings(
    // background
    val bgMode: BgMode = BgMode.COFFEE,
    val solidColor: Int = 0xFF51382C.toInt(),
    val gradientIndex: Int = 0,
    val imagePath: String? = null,
    val bgOpacity: Float = 0.92f,
    // text
    val textColor: Int = 0xFFFFF7EA.toInt(),
    val accentColor: Int = 0xFFC18A5A.toInt(),
    val font: FontChoice = FontChoice.SANS,
    val fontScale: Float = 1f,
    val bold: Boolean = true,
    val italic: Boolean = false,
    val align: Align = Align.CENTER,
    // widget
    val cornerRadius: Int = 28,
    val linesAround: Int = 1,
    val showTrackInfo: Boolean = true,
    // animation + language + sync
    val animStyle: AnimStyle = AnimStyle.KARAOKE,
    val animSpeed: Float = 1f,
    val scriptMode: ScriptMode = ScriptMode.ORIGINAL,
    val syncOffsetMs: Int = 0,
)
