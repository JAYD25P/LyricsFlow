package com.lyricflow.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Coffee = lightColorScheme(
    primary = Color(0xFF765039),
    onPrimary = Color(0xFFFFF8EF),
    primaryContainer = Color(0xFFEAD6C0),
    onPrimaryContainer = Color(0xFF38251D),
    secondary = Color(0xFFA8754D),
    onSecondary = Color(0xFFFFF8EF),
    secondaryContainer = Color(0xFFF0DDC8),
    onSecondaryContainer = Color(0xFF4A3022),
    tertiary = Color(0xFFB58A63),
    background = Color(0xFFF5EBDD),
    onBackground = Color(0xFF38251D),
    surface = Color(0xFFFFF9F1),
    onSurface = Color(0xFF38251D),
    surfaceVariant = Color(0xFFEADCCB),
    onSurfaceVariant = Color(0xFF715B49),
    outline = Color(0xFFBDA58D),
)

@Composable
fun LyricFlowTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = Coffee, content = content)
