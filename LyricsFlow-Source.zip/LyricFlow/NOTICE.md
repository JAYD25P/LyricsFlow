# Third-party attribution

CarLyrics (https://github.com/mliem2k/carlyrics) was used as a functional reference for the synced-lyrics and Android media-session/widget concept.

Upstream repository states that it is licensed under the MIT License. If any upstream source code is copied into this project, preserve the upstream copyright and MIT licence notice. This project also uses AndroidX, Jetpack Compose, Jetpack Glance, Kotlin Coroutines, and Android platform APIs; consult each dependency's licence before redistribution.

This notice is not a substitute for retaining the full licence text for any code copied from upstream.
