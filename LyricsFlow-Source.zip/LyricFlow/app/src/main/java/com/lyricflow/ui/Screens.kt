package com.lyricflow.ui

import android.content.Intent
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.glance.appwidget.GlanceAppWidgetManager
import com.lyricflow.data.Align
import com.lyricflow.data.AnimStyle
import com.lyricflow.data.BgMode
import com.lyricflow.data.FontChoice
import com.lyricflow.data.LrcLine
import com.lyricflow.data.LyricSettings
import com.lyricflow.data.ScriptMode
import com.lyricflow.playback.LyricsStatus
import com.lyricflow.playback.NowPlaying
import com.lyricflow.util.saveBackground
import com.lyricflow.widget.LyricWidgetReceiver
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

// ---------------------------------------------------------------- Now playing

@Composable
fun NowPlayingScreen(np: NowPlaying, s: LyricSettings, listenerOn: Boolean) {
    val ctx = LocalContext.current
    val dyn = rememberDynamicScheme()
    val colors = resolveColors(s, dyn)
    val pos by produceState(0L, np) {
        while (true) {
            value = np.positionMs()
            delay(if (np.playing) 33L else 300L)
        }
    }
    LyricBackground(s, Modifier.fillMaxSize().padding(12.dp), RoundedCornerShape(s.cornerRadius.dp), np.track?.art) {
        val track = np.track
        when {
            !listenerOn -> Message(
                "Let LyricFlow see what's playing",
                "Turn on notification access so lyrics can start the moment a song does. Nothing is read from your notifications.",
                colors,
            ) {
                Button(onClick = { ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }) {
                    Text("Open access settings")
                }
            }
            track == null -> Message("Nothing playing", "Start a song in Spotify, YouTube Music, JioSaavn or any music app.", colors)
            else -> {
                Column(Modifier.fillMaxSize()) {
                    Column(Modifier.fillMaxWidth().padding(20.dp, 20.dp, 20.dp, 0.dp)) {
                        Text(track.title, color = colors.text, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium, maxLines = 1)
                        Text(track.artist, color = colors.text.copy(alpha = 0.65f), style = MaterialTheme.typography.bodyMedium, maxLines = 1)
                    }
                    when (np.status) {
                        LyricsStatus.FOUND -> LyricsList(np.lyrics, pos, s, colors, Modifier.fillMaxSize())
                        LyricsStatus.MISSING -> Message("No synced lyrics found", "LRCLIB has no timed lyrics for this song yet.", colors)
                        else -> Message("Finding lyrics…", "", colors)
                    }
                }
            }
        }
    }
}

@Composable
private fun Message(title: String, body: String, c: LyricColors, action: @Composable () -> Unit = {}) {
    Column(
        Modifier.fillMaxSize().padding(28.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally,
    ) {
        Text(title, color = c.text, style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold, textAlign = TextAlign.Center)
        if (body.isNotEmpty()) {
            Text(body, color = c.text.copy(alpha = 0.7f), style = MaterialTheme.typography.bodyMedium, textAlign = TextAlign.Center, modifier = Modifier.padding(top = 8.dp, bottom = 16.dp))
        }
        action()
    }
}

// ---------------------------------------------------------------- Customise

// Original sample lines, one per script, so every language and the Hinglish option can be previewed.
private val demo = listOf(
    LrcLine(0, "Turn the lights down low"),
    LrcLine(3200, "तुम्हारे साथ हर पल है सुहाना"),
    LrcLine(6400, "Dil ki baat dil se kehni hai"),
    LrcLine(9600, "별빛 아래 우리 함께 춤춰요"),
    LrcLine(12800, "夜空に光る夢を追いかけて"),
    LrcLine(16000, "نغني تحت ضوء القمر"),
    LrcLine(19200, "Bailemos hasta el amanecer"),
)
private const val DEMO_LOOP_MS = 22_400L

@Composable
fun CustomiseScreen(s: LyricSettings, listenerOn: Boolean, onUpdate: ((LyricSettings) -> LyricSettings) -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val dyn = rememberDynamicScheme()
    val colors = resolveColors(s, dyn)
    val system = s.bgMode == BgMode.SYSTEM

    val demoPos by produceState(0L) {
        val t0 = System.nanoTime()
        while (true) {
            value = ((System.nanoTime() - t0) / 1_000_000) % DEMO_LOOP_MS
            delay(33L)
        }
    }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri ->
        if (uri != null) scope.launch {
            saveBackground(ctx, uri)?.let { path -> onUpdate { it.copy(imagePath = path, bgMode = BgMode.IMAGE) } }
        }
    }

    Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(horizontal = 20.dp).padding(bottom = 48.dp)) {
        LyricBackground(s, Modifier.fillMaxWidth().height(230.dp).padding(top = 12.dp), RoundedCornerShape(s.cornerRadius.dp)) {
            LyricsList(demo, demoPos, s, colors, Modifier.fillMaxSize(), scrollable = false)
        }

        Section("Language", "Hindi lyrics become Hinglish (\"प्यार\" → \"pyaar\"). Arabic, Korean, Japanese, Tamil, Russian, Thai, Chinese and other scripts are converted to Roman letters too. English and Hinglish lyrics stay as they are.") {
            ChipRow(ScriptMode.entries, s.scriptMode, { it.label }) { v -> onUpdate { it.copy(scriptMode = v) } }
        }

        Section("Background", "Opacity lets your wallpaper show through the widget.") {
            ChipRow(BgMode.entries, s.bgMode, { it.label }) { v -> onUpdate { it.copy(bgMode = v) } }
            when (s.bgMode) {
                BgMode.SOLID -> ColorRow("Colour", s.solidColor) { c -> onUpdate { it.copy(solidColor = c) } }
                BgMode.GRADIENT -> GradientRow(s.gradientIndex) { i -> onUpdate { it.copy(gradientIndex = i) } }
                BgMode.IMAGE -> OutlinedButton(onClick = {
                    picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly))
                }) { Text(if (s.imagePath == null) "Choose a photo" else "Change photo") }
                BgMode.ALBUM_ART -> Text("Uses a soft blur of the current song's cover.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                BgMode.SYSTEM -> Text("Follows your phone's Material You colours (Android 12+).", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
            if (!system) SliderRow("Opacity", s.bgOpacity, 0.1f..1f, { "${(it * 100).toInt()}%" }) { v -> onUpdate { it.copy(bgOpacity = v) } }
        }

        Section("Text") {
            if (!system) {
                ColorRow("Lyric colour", s.textColor) { c -> onUpdate { it.copy(textColor = c) } }
                ColorRow("Highlight colour", s.accentColor) { c -> onUpdate { it.copy(accentColor = c) } }
            }
            ChipRow(FontChoice.entries, s.font, { it.label }) { v -> onUpdate { it.copy(font = v) } }
            ChipRow(Align.entries, s.align, { it.label }) { v -> onUpdate { it.copy(align = v) } }
            SliderRow("Size", s.fontScale, 0.7f..1.6f, { "%.1fx".format(it) }) { v -> onUpdate { it.copy(fontScale = v) } }
            SwitchRowPair(s, onUpdate)
        }

        Section("Animation", "Shown in the preview above and on the Now playing tab. Home-screen widgets can't run custom animations, so the widget changes line instantly.") {
            ChipRow(AnimStyle.entries, s.animStyle, { it.label }) { v -> onUpdate { it.copy(animStyle = v) } }
            SliderRow("Speed", s.animSpeed, 0.5f..2f, { "%.1fx".format(it) }) { v -> onUpdate { it.copy(animSpeed = v) } }
        }

        Section("Widget") {
            SliderRow("Corner radius", s.cornerRadius.toFloat(), 0f..48f, { "${it.toInt()} dp" }) { v -> onUpdate { it.copy(cornerRadius = v.toInt()) } }
            SliderRow("Lines before and after", s.linesAround.toFloat(), 0f..2f, { it.toInt().toString() }, steps = 1) { v -> onUpdate { it.copy(linesAround = v.toInt()) } }
            com.lyricflow.ui.SwitchRow("Show song and artist", s.showTrackInfo) { v -> onUpdate { it.copy(showTrackInfo = v) } }
            SliderRow("Sync nudge", s.syncOffsetMs.toFloat(), -3000f..3000f, { "%+.1f s".format(it / 1000f) }, steps = 59) { v -> onUpdate { it.copy(syncOffsetMs = (v / 100).toInt() * 100) } }
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = {
                    scope.launch { GlanceAppWidgetManager(ctx).requestPinGlanceAppWidget(LyricWidgetReceiver::class.java) }
                }) { Text("Add to home screen") }
                OutlinedButton(onClick = { onUpdate { LyricSettings() } }) { Text("Reset") }
            }
            if (!listenerOn) {
                OutlinedButton(onClick = {
                    ctx.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                }) { Text("Turn on notification access") }
            }
        }
    }
}

@Composable
private fun SwitchRowPair(s: LyricSettings, onUpdate: ((LyricSettings) -> LyricSettings) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
        SwitchRow("Bold", s.bold) { v -> onUpdate { it.copy(bold = v) } }
        SwitchRow("Italic", s.italic) { v -> onUpdate { it.copy(italic = v) } }
    }
}
