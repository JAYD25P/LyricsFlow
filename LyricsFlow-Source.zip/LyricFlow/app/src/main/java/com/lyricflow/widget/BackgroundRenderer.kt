package com.lyricflow.widget

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import com.lyricflow.data.BgMode
import com.lyricflow.data.LyricSettings
import com.lyricflow.data.Presets
import kotlin.math.max

/** Paints the widget background (solid / gradient / album art / photo) into one small bitmap. */
object BackgroundRenderer {
    private const val W = 720
    private const val H = 360

    fun render(s: LyricSettings, art: Bitmap?): Bitmap {
        val layer = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val c = Canvas(layer)
        val gradient = Presets.gradients[s.gradientIndex.coerceIn(Presets.gradients.indices)]

        when (s.bgMode) {
            BgMode.SOLID -> c.drawColor(s.solidColor)
            BgMode.ALBUM_ART -> {
                if (art != null) {
                    // tiny version scaled up = cheap, soft "frosted" blur
                    drawCover(c, Bitmap.createScaledBitmap(art, 24, 24, true))
                    c.drawColor(Color.argb(120, 0, 0, 0))
                } else drawGradient(c, gradient.colors)
            }
            BgMode.IMAGE -> {
                val photo = s.imagePath?.let { BitmapFactory.decodeFile(it) }
                if (photo != null) {
                    drawCover(c, photo)
                    c.drawColor(Color.argb(110, 0, 0, 0))
                } else drawGradient(c, gradient.colors)
            }
            else -> drawGradient(c, gradient.colors)
        }

        val out = Bitmap.createBitmap(W, H, Bitmap.Config.ARGB_8888)
        val paint = Paint(Paint.FILTER_BITMAP_FLAG).apply { alpha = (s.bgOpacity.coerceIn(0f, 1f) * 255).toInt() }
        Canvas(out).drawBitmap(layer, 0f, 0f, paint)
        layer.recycle()
        return out
    }

    private fun drawGradient(c: Canvas, colors: List<Int>) {
        val p = Paint(Paint.ANTI_ALIAS_FLAG)
        p.shader = LinearGradient(0f, 0f, W.toFloat(), H.toFloat(), colors.toIntArray(), null, Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, W.toFloat(), H.toFloat(), p)
    }

    private fun drawCover(c: Canvas, src: Bitmap) {
        val scale = max(W / src.width.toFloat(), H / src.height.toFloat())
        val dw = src.width * scale
        val dh = src.height * scale
        c.drawBitmap(src, null, RectF((W - dw) / 2, (H - dh) / 2, (W + dw) / 2, (H + dh) / 2), Paint(Paint.FILTER_BITMAP_FLAG))
    }
}
