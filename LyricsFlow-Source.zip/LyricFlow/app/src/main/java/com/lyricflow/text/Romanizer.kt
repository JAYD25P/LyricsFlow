package com.lyricflow.text

import android.icu.text.Transliterator
import android.util.LruCache
import com.lyricflow.data.ScriptMode

/** Prepares a lyric line for display: original, Roman/Hinglish, or both. */
object LyricText {
    /** Returns (main line, optional second line). */
    fun prepare(mode: ScriptMode, raw: String): Pair<String, String?> {
        val t = raw.ifBlank { "♪" }
        return when (mode) {
            ScriptMode.ORIGINAL -> t to null
            ScriptMode.HINGLISH -> Romanizer.toRoman(t) to null
            ScriptMode.BOTH -> {
                val r = Romanizer.toRoman(t)
                t to r.takeIf { !it.equals(t, ignoreCase = true) }
            }
        }
    }
}

/**
 * Converts any non-Latin script to Roman letters.
 *  - Devanagari (Hindi, Marathi, Nepali...) uses a hand-written Hinglish converter
 *    ("प्यार" -> "pyaar", "तुम्हारा" -> "tumhara") with schwa deletion.
 *  - Every other script (Arabic, Korean, Japanese, Tamil, Cyrillic, Thai, Chinese...) goes
 *    through Android's built-in ICU transliterator.
 *  - Lines already in Latin letters (English, Hinglish) pass through unchanged.
 */
object Romanizer {
    private val devanagariRun = Regex("[\\u0900-\\u097F\\u200C\\u200D]+")
    private val cache = LruCache<String, String>(512)
    private val icu: Transliterator? by lazy {
        runCatching { Transliterator.getInstance("Any-Latin; Latin-ASCII") }.getOrNull()
    }

    fun needsRoman(text: String): Boolean = text.any {
        it.isLetter() && Character.UnicodeScript.of(it.code).let { sc ->
            sc != Character.UnicodeScript.LATIN && sc != Character.UnicodeScript.COMMON &&
                sc != Character.UnicodeScript.INHERITED
        }
    }

    fun toRoman(text: String): String {
        if (!needsRoman(text)) return text
        cache.get(text)?.let { return it }
        var out = devanagariRun.replace(text) { Hinglish.fromDevanagari(it.value) }
        if (needsRoman(out)) out = runCatching { icu?.transliterate(out) }.getOrNull() ?: out
        out = out.replaceFirstChar { it.uppercase() }
        cache.put(text, out)
        return out
    }
}

/** Rule-based Devanagari -> Hinglish (how people actually type Hindi in Roman letters). */
object Hinglish {
    // U+0915..U+0939 consonants
    private val CONS = arrayOf(
        "k", "kh", "g", "gh", "n", "ch", "chh", "j", "jh", "n", "t", "th", "d", "dh", "n",
        "t", "th", "d", "dh", "n", "n", "p", "ph", "b", "bh", "m", "y", "r", "r", "l", "l", "l",
        "v", "sh", "sh", "s", "h",
    )
    // U+0958..U+095F nukta consonants
    private val NUKTA = arrayOf("q", "kh", "g", "z", "d", "dh", "f", "y")
    // U+0905..U+0914 independent vowels
    private val VOW = arrayOf("a", "aa", "i", "ee", "u", "oo", "ri", "li", "e", "e", "e", "ai", "o", "o", "o", "au")
    // U+093E..U+094C vowel signs
    private val MATRA = arrayOf("aa", "i", "ee", "u", "oo", "ri", "ri", "e", "e", "e", "ai", "o", "o", "o", "au")
    private val SEMIVOWELS = setOf("y", "r", "v")

    private class Syl(
        var cons: String = "",
        var vowel: String? = null,
        var schwa: Boolean = false,
        var halant: Boolean = false,
        var tail: String = "",
    )

    /** [run] is a run of Devanagari characters (a word). */
    fun fromDevanagari(run: String): String {
        val us = ArrayList<Syl>()
        for (ch in run) {
            val c = ch.code
            when {
                c in 0x0915..0x0939 -> us += Syl(CONS[c - 0x0915], null, true)
                c in 0x0958..0x095F -> us += Syl(NUKTA[c - 0x0958], null, true)
                c == 0x093C -> us.lastOrNull()?.let {
                    it.cons = when (it.cons) { "k" -> "q"; "j" -> "z"; "ph" -> "f"; else -> it.cons }
                }
                c in 0x0905..0x0914 -> us += Syl("", VOW[c - 0x0905], false)
                c in 0x093E..0x094C -> us.lastOrNull()?.let {
                    if (it.cons.isNotEmpty() && it.vowel == null) { it.vowel = MATRA[c - 0x093E]; it.schwa = false }
                }
                c == 0x094D -> us.lastOrNull()?.let { it.schwa = false; it.halant = true }
                c == 0x0900 || c == 0x0901 || c == 0x0902 -> us.lastOrNull()?.let { it.tail += "n" }
                c == 0x0903 -> us.lastOrNull()?.let { it.tail += "h" }
                c == 0x0950 -> us += Syl("om", "", false)
                c in 0x0966..0x096F -> us += Syl((c - 0x0966).toString(), "", false)
            }
        }
        val n = us.size
        val drop = BooleanArray(n)
        // Hindi schwa deletion, right to left.
        for (i in n - 1 downTo 0) {
            val u = us[i]
            if (!u.schwa || u.tail.isNotEmpty()) continue
            if (i == n - 1) {
                if (n == 1) continue
                if (us[i - 1].halant && u.cons in SEMIVOWELS) continue // satya, mitra
                drop[i] = true
            } else if (i > 0) {
                val prev = us[i - 1]
                val next = us[i + 1]
                val prevHas = prev.vowel != null || prev.schwa
                val nextHas = next.vowel != null || (next.schwa && !drop[i + 1])
                if (prevHas && nextHas) drop[i] = true
            }
        }
        val sb = StringBuilder()
        for (i in 0 until n) {
            val u = us[i]
            sb.append(u.cons)
            var v = u.vowel ?: if (u.schwa && !drop[i]) "a" else ""
            if (u.tail.isNotEmpty()) {
                if (v == "e") v = "ei"      // में -> mein, हैं -> hain
                if (v == "ee") v = "i"      // नहीं -> nahin
            } else if (i == n - 1 && u.cons.isNotEmpty()) {
                v = when (v) { "aa" -> "a"; "ee" -> "i"; "oo" -> "u"; else -> v } // तेरा -> tera, की -> ki
            }
            sb.append(v).append(u.tail)
        }
        return sb.toString()
    }
}
