package com.lyricflow.ui

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.glance.appwidget.updateAll
import com.lyricflow.data.LyricSettings
import com.lyricflow.data.SettingsRepo
import com.lyricflow.playback.NowPlayingStore
import com.lyricflow.util.isListenerEnabled
import com.lyricflow.widget.LyricWidget
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent { LyricFlowTheme { App() } }
    }
}

@Composable
private fun App() {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val settings by remember { SettingsRepo.flow(ctx) }.collectAsState(initial = LyricSettings())
    val np by NowPlayingStore.state.collectAsState()
    var tab by remember { mutableIntStateOf(0) }
    var listenerOn by remember { mutableStateOf(isListenerEnabled(ctx)) }

    LaunchedEffect(Unit) {
        while (true) { listenerOn = isListenerEnabled(ctx); delay(1000) }
    }
    // Any settings change repaints the home-screen widget (debounced).
    LaunchedEffect(settings) {
        delay(350)
        runCatching { LyricWidget().updateAll(ctx) }
    }
    val update: ((LyricSettings) -> LyricSettings) -> Unit = { change ->
        scope.launch { SettingsRepo.update(ctx, change) }
    }

    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).statusBarsPadding()) {
        TabRow(selectedTabIndex = tab, containerColor = Color.Transparent, contentColor = MaterialTheme.colorScheme.primary) {
            Tab(selected = tab == 0, onClick = { tab = 0 }, text = { Text("Now playing") })
            Tab(selected = tab == 1, onClick = { tab = 1 }, text = { Text("Customise") })
        }
        Box(Modifier.weight(1f).navigationBarsPadding()) {
            if (tab == 0) NowPlayingScreen(np, settings, listenerOn)
            else CustomiseScreen(settings, listenerOn, update)
        }
    }
}
