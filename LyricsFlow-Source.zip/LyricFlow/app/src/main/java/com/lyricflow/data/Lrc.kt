package com.lyricflow.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.security.MessageDigest
import kotlin.math.abs

object LrcParser {
    private val stamp = Regex("""\[(\d{1,3}):(\d{2})(?:[.:](\d{1,3}))?]""")

    fun parse(lrc: String): List<LrcLine> {
        val out = ArrayList<LrcLine>()
        for (raw in lrc.lineSequence()) {
            val stamps = stamp.findAll(raw).toList()
            if (stamps.isEmpty()) continue
            val text = raw.substring(stamps.last().range.last + 1).trim()
            for (m in stamps) {
                val min = m.groupValues[1].toLong()
                val sec = m.groupValues[2].toLong()
                val frac = m.groupValues[3].padEnd(3, '0').take(3).toLongOrNull() ?: 0L
                out += LrcLine(min * 60_000 + sec * 1000 + frac, text)
            }
        }
        return out.sortedBy { it.timeMs }
    }
}

/** Fetches time-synced lyrics from LRCLIB (free, no API key) and caches them on disk. */
object LrclibClient {
    private const val BASE = "https://lrclib.net/api"
    private val misses = HashSet<String>()

    suspend fun lyricsFor(ctx: Context, id: String, title: String, artist: String, album: String?, durationMs: Long): List<LrcLine> =
        withContext(Dispatchers.IO) {
            val file = File(ctx.filesDir, "lyrics/${sha1(id)}.lrc")
            if (file.exists()) return@withContext LrcParser.parse(file.readText())
            if (id in misses) return@withContext emptyList()
            val lrc = find(title, artist, album, durationMs / 1000)
            if (lrc == null) {
                misses += id
                emptyList()
            } else {
                file.parentFile?.mkdirs()
                file.writeText(lrc)
                LrcParser.parse(lrc)
            }
        }

    /** Saves an imported .lrc for a track (used by "import LRC" style features). */
    fun save(ctx: Context, id: String, lrc: String) {
        val f = File(ctx.filesDir, "lyrics/${sha1(id)}.lrc")
        f.parentFile?.mkdirs()
        f.writeText(lrc)
        misses.remove(id)
    }

    private fun find(title: String, artist: String, album: String?, dur: Long): String? {
        val clean = cleanTitle(title)
        val mainArtist = artist.split(",", "&", " feat", " ft.").first().trim()
        return get(title, artist, album, dur)
            ?: get(clean, mainArtist, null, dur)
            ?: search("$mainArtist $clean", dur)
            ?: search(clean, dur)
    }

    private fun get(title: String, artist: String, album: String?, dur: Long): String? {
        val url = buildString {
            append("$BASE/get?track_name=${enc(title)}&artist_name=${enc(artist)}")
            if (!album.isNullOrBlank()) append("&album_name=${enc(album)}")
            if (dur > 0) append("&duration=$dur")
        }
        val body = http(url) ?: return null
        val synced = runCatching { JSONObject(body).optString("syncedLyrics") }.getOrNull() ?: return null
        return synced.takeIf { it.isNotBlank() && it != "null" }
    }

    private fun search(q: String, dur: Long): String? {
        val body = http("$BASE/search?q=${enc(q)}") ?: return null
        val arr = runCatching { JSONArray(body) }.getOrNull() ?: return null
        var best: String? = null
        var bestDiff = Long.MAX_VALUE
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            val synced = o.optString("syncedLyrics")
            if (synced.isBlank() || synced == "null") continue
            val diff = if (dur > 0) abs(o.optLong("duration") - dur) else 0L
            if (diff < bestDiff) { best = synced; bestDiff = diff }
        }
        return if (best != null && (dur <= 0 || bestDiff <= 8)) best else null
    }

    private fun cleanTitle(s: String): String =
        s.replace(Regex("""\s*[(\[].*?[)\]]"""), "")
            .replace(Regex("""\s+-\s+.*$"""), "")
            .trim()
            .ifEmpty { s }

    private fun http(url: String): String? = runCatching {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 8000
        c.readTimeout = 8000
        c.setRequestProperty("User-Agent", "LyricFlow/1.0")
        if (c.responseCode == 200) c.inputStream.bufferedReader().use { it.readText() } else null
    }.getOrNull()

    private fun enc(s: String) = URLEncoder.encode(s, "UTF-8")

    private fun sha1(s: String) =
        MessageDigest.getInstance("SHA-1").digest(s.toByteArray()).joinToString("") { "%02x".format(it) }
}
