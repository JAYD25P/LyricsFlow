package com.lyricflow.widget

import android.content.Context
import android.graphics.Bitmap
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.glance.GlanceId
import androidx.glance.GlanceModifier
import androidx.glance.GlanceTheme
import androidx.glance.Image
import androidx.glance.ImageProvider
import androidx.glance.LocalSize
import androidx.glance.action.clickable
import androidx.glance.appwidget.GlanceAppWidget
import androidx.glance.appwidget.GlanceAppWidgetReceiver
import androidx.glance.appwidget.SizeMode
import androidx.glance.appwidget.action.actionStartActivity
import androidx.glance.appwidget.appWidgetBackground
import androidx.glance.appwidget.cornerRadius
import androidx.glance.appwidget.provideContent
import androidx.glance.background
import androidx.glance.layout.Alignment
import androidx.glance.layout.Box
import androidx.glance.layout.Column
import androidx.glance.layout.ContentScale
import androidx.glance.layout.Spacer
import androidx.glance.layout.fillMaxSize
import androidx.glance.layout.fillMaxWidth
import androidx.glance.layout.height
import androidx.glance.layout.padding
import androidx.glance.text.FontStyle
import androidx.glance.text.FontWeight
import androidx.glance.text.Text
import androidx.glance.text.TextAlign
import androidx.glance.text.TextStyle
import androidx.glance.unit.ColorProvider
import com.lyricflow.data.Align
import com.lyricflow.data.BgMode
import com.lyricflow.data.FontChoice
import com.lyricflow.data.LyricSettings
import com.lyricflow.data.SettingsRepo
import com.lyricflow.data.indexAt
import com.lyricflow.playback.LyricsStatus
import com.lyricflow.playback.NowPlaying
import com.lyricflow.playback.NowPlayingStore
import com.lyricflow.text.LyricText
import com.lyricflow.ui.MainActivity
import com.lyricflow.util.isListenerEnabled
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.withContext
import androidx.glance.text.FontFamily as GlanceFontFamily

class LyricWidgetReceiver : GlanceAppWidgetReceiver() {
    override val glanceAppWidget: GlanceAppWidget = LyricWidget()
}

class LyricWidget : GlanceAppWidget() {
    override val sizeMode: SizeMode = SizeMode.Exact

    override suspend fun provideGlance(context: Context, id: GlanceId) {
        val s = SettingsRepo.flow(context).first()
        val np = NowPlayingStore.state.value
        val bg = if (s.bgMode == BgMode.SYSTEM) null
        else withContext(Dispatchers.Default) { BackgroundRenderer.render(s, np.track?.art) }
        val listening = isListenerEnabled(context)
        provideContent {
            GlanceTheme { WidgetBody(s, np, bg, listening) }
        }
    }
}

@Composable
private fun WidgetBody(s: LyricSettings, np: NowPlaying, bg: Bitmap?, listening: Boolean) {
    val system = s.bgMode == BgMode.SYSTEM
    val text: ColorProvider = if (system) GlanceTheme.colors.onSurface else ColorProvider(Color(s.textColor))
    val dim: ColorProvider = if (system) GlanceTheme.colors.onSurfaceVariant
    else ColorProvider(Color(s.textColor).copy(alpha = 0.55f))
    val accent: ColorProvider = if (system) GlanceTheme.colors.primary else ColorProvider(Color(s.accentColor))

    // Adapt to the size the user stretched the widget to.
    val h = LocalSize.current.height.value
    val base = when { h < 90 -> 14f; h < 150 -> 18f; h < 250 -> 22f; else -> 28f } * s.fontScale
    val around = when { h < 110 -> 0; h < 170 -> minOf(s.linesAround, 1); else -> s.linesAround }

    val hAlign = when (s.align) {
        Align.START -> Alignment.Start
        Align.CENTER -> Alignment.CenterHorizontally
        Align.END -> Alignment.End
    }
    val tAlign = when (s.align) {
        Align.START -> TextAlign.Start
        Align.CENTER -> TextAlign.Center
        Align.END -> TextAlign.End
    }
    val family = when (s.font) {
        FontChoice.SANS -> GlanceFontFamily.SansSerif
        FontChoice.SERIF -> GlanceFontFamily.Serif
        FontChoice.MONO -> GlanceFontFamily.Monospace
        FontChoice.CURSIVE -> GlanceFontFamily.Cursive
    }
    fun style(color: ColorProvider, size: Float, bold: Boolean) = TextStyle(
        color = color,
        fontSize = size.sp,
        fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal,
        fontStyle = if (s.italic) FontStyle.Italic else FontStyle.Normal,
        textAlign = tAlign,
        fontFamily = family,
    )

    val rootModifier = GlanceModifier
        .fillMaxSize()
        .appWidgetBackground()
        .cornerRadius(s.cornerRadius.dp)
        .let { if (system) it.background(GlanceTheme.colors.widgetBackground) else it }
        .clickable(actionStartActivity<MainActivity>())

    Box(modifier = rootModifier) {
        if (bg != null) {
            Image(ImageProvider(bg), null, GlanceModifier.fillMaxSize(), ContentScale.Crop)
        }
        Column(
            modifier = GlanceModifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalAlignment = hAlign,
        ) {
            val track = np.track
            when {
                !listening ->
                    Text("Tap to switch on lyrics access", GlanceModifier.fillMaxWidth(), style(accent, base * 0.8f, true))
                track == null ->
                    Text("Play a song to see lyrics", GlanceModifier.fillMaxWidth(), style(dim, base * 0.8f, false))
                else -> {
                    if (s.showTrackInfo && h >= 90) {
                        Text(
                            "${track.title} · ${track.artist}",
                            GlanceModifier.fillMaxWidth(),
                            style(dim, base * 0.55f, false),
                            maxLines = 1,
                        )
                        Spacer(GlanceModifier.height(4.dp))
                    }
                    when (np.status) {
                        LyricsStatus.IDLE, LyricsStatus.LOADING ->
                            Text("Finding lyrics…", GlanceModifier.fillMaxWidth(), style(dim, base * 0.8f, false))
                        LyricsStatus.MISSING ->
                            Text("No synced lyrics for this song", GlanceModifier.fillMaxWidth(), style(dim, base * 0.8f, false))
                        LyricsStatus.FOUND -> {
                            val idx = np.lyrics.indexAt(np.positionMs() + s.syncOffsetMs)
                            for (k in -around..around) {
                                val line = np.lyrics.getOrNull(idx + k)
                                val raw = if (line != null) line.text else if (k == 0) "" else continue
                                val (main, sub) = LyricText.prepare(s.scriptMode, raw)
                                val current = k == 0
                                Text(
                                    main,
                                    GlanceModifier.fillMaxWidth(),
                                    style(if (current) accent else dim, if (current) base else base * 0.7f, current && s.bold),
                                    maxLines = if (current) 3 else 1,
                                )
                                if (current && sub != null) {
                                    Text(sub, GlanceModifier.fillMaxWidth(), style(text, base * 0.6f, false), maxLines = 2)
                                }
                                Spacer(GlanceModifier.height(3.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}
