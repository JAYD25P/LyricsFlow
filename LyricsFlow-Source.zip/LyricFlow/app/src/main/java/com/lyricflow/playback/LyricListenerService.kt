package com.lyricflow.playback

import android.content.ComponentName
import android.content.Context
import android.media.MediaMetadata
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.media.session.PlaybackState
import android.os.SystemClock
import android.service.notification.NotificationListenerService
import androidx.glance.appwidget.updateAll
import com.lyricflow.data.LrclibClient
import com.lyricflow.data.SettingsRepo
import com.lyricflow.widget.LyricWidget
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Once the user grants "Notification access", Android lets this service watch every active
 * media session (Spotify, YouTube Music, JioSaavn, Apple Music, local players...). The moment a
 * song starts we fetch its synced lyrics and keep the widget on the right line.
 */
class LyricListenerService : NotificationListenerService() {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main.immediate)
    private var manager: MediaSessionManager? = null
    private var component: ComponentName? = null
    private var controller: MediaController? = null
    private var tick: Job? = null
    private var fetch: Job? = null
    private var settingsJob: Job? = null
    @Volatile private var offsetMs = 0L

    private val sessionsChanged = MediaSessionManager.OnActiveSessionsChangedListener { pick(it) }

    private val callback = object : MediaController.Callback() {
        override fun onMetadataChanged(metadata: MediaMetadata?) = onMeta(metadata)
        override fun onPlaybackStateChanged(state: PlaybackState?) = onState(state)
        override fun onSessionDestroyed() = pick(sessions())
    }

    override fun onListenerConnected() {
        val m = getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
        manager = m
        component = ComponentName(this, LyricListenerService::class.java)
        runCatching { m.addOnActiveSessionsChangedListener(sessionsChanged, component) }
        settingsJob?.cancel()
        settingsJob = scope.launch {
            SettingsRepo.flow(applicationContext).collect {
                val o = it.syncOffsetMs.toLong()
                if (o != offsetMs) { offsetMs = o; restartTick() }
            }
        }
        pick(sessions())
    }

    override fun onListenerDisconnected() = teardown()

    override fun onDestroy() {
        teardown()
        scope.cancel()
        super.onDestroy()
    }

    private fun teardown() {
        tick?.cancel(); fetch?.cancel(); settingsJob?.cancel()
        controller?.unregisterCallback(callback)
        controller = null
        runCatching { manager?.removeOnActiveSessionsChangedListener(sessionsChanged) }
    }

    private fun sessions(): List<MediaController> =
        runCatching { manager?.getActiveSessions(component) }.getOrNull().orEmpty()

    private fun pick(list: List<MediaController>?) {
        val best = list?.firstOrNull { it.playbackState?.state == PlaybackState.STATE_PLAYING }
            ?: list?.firstOrNull()
        if (best?.sessionToken == controller?.sessionToken && best != null) return
        controller?.unregisterCallback(callback)
        controller = best
        if (best == null) {
            NowPlayingStore.state.value = NowPlaying()
            restartTick()
            return
        }
        best.registerCallback(callback)
        onMeta(best.metadata)
        onState(best.playbackState)
    }

    private fun onMeta(m: MediaMetadata?) {
        val title = m?.getString(MediaMetadata.METADATA_KEY_TITLE)?.trim().orEmpty()
        if (m == null || title.isEmpty()) {
            fetch?.cancel()
            NowPlayingStore.state.value = NowPlaying()
            restartTick()
            return
        }
        val artist = (m.getString(MediaMetadata.METADATA_KEY_ARTIST)
            ?: m.getString(MediaMetadata.METADATA_KEY_ALBUM_ARTIST) ?: "").trim()
        val album = m.getString(MediaMetadata.METADATA_KEY_ALBUM)
        val dur = m.getLong(MediaMetadata.METADATA_KEY_DURATION)
        val art = m.getBitmap(MediaMetadata.METADATA_KEY_ALBUM_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_ART)
            ?: m.getBitmap(MediaMetadata.METADATA_KEY_DISPLAY_ICON)
        val id = "$artist|$title".lowercase()
        val track = Track(id, title, artist, album, dur, art)

        if (NowPlayingStore.state.value.track?.id == id) {
            NowPlayingStore.state.update { it.copy(track = track) }
            restartTick()
            return
        }
        fetch?.cancel()
        NowPlayingStore.state.update {
            it.copy(track = track, lyrics = emptyList(), status = LyricsStatus.LOADING)
        }
        restartTick()
        fetch = scope.launch {
            val lines = LrclibClient.lyricsFor(applicationContext, id, title, artist, album, dur)
            NowPlayingStore.state.update {
                if (it.track?.id == id) {
                    it.copy(lyrics = lines, status = if (lines.isEmpty()) LyricsStatus.MISSING else LyricsStatus.FOUND)
                } else it
            }
            restartTick()
        }
    }

    private fun onState(s: PlaybackState?) {
        val playing = s?.state == PlaybackState.STATE_PLAYING
        val now = SystemClock.elapsedRealtime()
        val at = s?.lastPositionUpdateTime?.takeIf { it > 0 } ?: now
        NowPlayingStore.state.update {
            it.copy(
                playing = playing,
                anchorPosMs = (s?.position ?: 0L).coerceAtLeast(0L),
                anchorAtMs = at,
                speed = s?.playbackSpeed?.takeIf { sp -> sp > 0f } ?: 1f,
            )
        }
        restartTick()
    }

    /** Redraws the widget now, then again exactly when each next lyric line begins. */
    private fun restartTick() {
        tick?.cancel()
        tick = scope.launch {
            redraw()
            while (isActive) {
                val np = NowPlayingStore.state.value
                if (!np.playing || np.lyrics.isEmpty()) break
                val pos = np.positionMs() + offsetMs
                val next = np.lyrics.getOrNull(np.indexAt(pos) + 1) ?: break
                delay(((next.timeMs - pos) / np.speed).toLong().coerceAtLeast(40L))
                redraw()
            }
        }
    }

    private suspend fun redraw() {
        runCatching { LyricWidget().updateAll(applicationContext) }
    }
}
