package com.lyricflow.playback

import android.graphics.Bitmap
import android.os.SystemClock
import com.lyricflow.data.LrcLine
import com.lyricflow.data.indexAt
import kotlinx.coroutines.flow.MutableStateFlow

data class Track(
    val id: String,
    val title: String,
    val artist: String,
    val album: String?,
    val durationMs: Long,
    val art: Bitmap?,
)

enum class LyricsStatus { IDLE, LOADING, FOUND, MISSING }

data class NowPlaying(
    val track: Track? = null,
    val lyrics: List<LrcLine> = emptyList(),
    val status: LyricsStatus = LyricsStatus.IDLE,
    val playing: Boolean = false,
    val anchorPosMs: Long = 0,
    val anchorAtMs: Long = 0, // SystemClock.elapsedRealtime() when anchorPosMs was true
    val speed: Float = 1f,
) {
    /** Live playback position, extrapolated from the last report by the media app. */
    fun positionMs(now: Long = SystemClock.elapsedRealtime()): Long =
        if (playing) anchorPosMs + ((now - anchorAtMs) * speed).toLong() else anchorPosMs

    fun indexAt(posMs: Long): Int = lyrics.indexAt(posMs)
}

/** Process-wide holder read by the widget and the in-app screens. */
object NowPlayingStore {
    val state = MutableStateFlow(NowPlaying())
}
