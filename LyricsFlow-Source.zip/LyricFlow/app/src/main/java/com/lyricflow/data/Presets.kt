package com.lyricflow.data

data class Gradient(val name: String, val colors: List<Int>)

object Presets {
    private fun opaque(rgb: Int) = rgb or 0xFF000000.toInt()
    private fun g(name: String, vararg rgb: Int) = Gradient(name, rgb.map { opaque(it) })

    val gradients = listOf(
        g("Midnight Mango", 0x1B1033, 0x8E2DE2, 0xFF7A59),
        g("Neon Tokyo", 0x0F0C29, 0x6A11CB, 0x2575FC),
        g("Sunset Drive", 0x2B1055, 0xD53369, 0xFFB75E),
        g("Ocean Deep", 0x000428, 0x004E92),
        g("Aurora", 0x0B3D2E, 0x1CB5A3, 0x7F5AF0),
        g("Rose Quartz", 0x3A1C71, 0xD76D77, 0xFFAF7B),
        g("Forest Night", 0x0B1F14, 0x134E32, 0x3DDC97),
        g("Bubblegum", 0xFF6FD8, 0x3813C2),
        g("Lava", 0x200122, 0x6F0000, 0xFF4E50),
        g("Glacier", 0x0F2027, 0x2193B0, 0x6DD5ED),
        g("Slate", 0x111111, 0x2D2D2D),
        g("Peach Fuzz", 0xFFB88C, 0xDE6262),
        g("Electric Lime", 0x0A0F0D, 0x00C9A7, 0xC4FF61),
        g("Royal", 0x141E30, 0x243B55),
        g("Cherry Cola", 0x1D0B0B, 0x7B1E3A, 0xFF4E50),
    )

    val swatches: List<Int> = listOf(
        0xFFFFFF, 0xFF6FD8, 0xFF4E50, 0xFF7A59, 0xFFB75E, 0xFFE066, 0xC4FF61, 0x3DDC97,
        0x00C9A7, 0x6DD5ED, 0x2575FC, 0x9D7BFF, 0x8E2DE2, 0x1B1033, 0x111111, 0x000000,
    ).map { opaque(it) }
}
