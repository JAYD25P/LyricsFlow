package com.lyricflow.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Stage = darkColorScheme(
    primary = Color(0xFFFF6FD8),
    onPrimary = Color(0xFF2B0A26),
    secondary = Color(0xFF9D7BFF),
    background = Color(0xFF0D0A1F),
    onBackground = Color(0xFFF2EEFF),
    surface = Color(0xFF17122E),
    onSurface = Color(0xFFF2EEFF),
    surfaceVariant = Color(0xFF241D44),
    onSurfaceVariant = Color(0xFFB9B0D9),
    outline = Color(0xFF4B4278),
)

@Composable
fun LyricFlowTheme(content: @Composable () -> Unit) = MaterialTheme(colorScheme = Stage, content = content)
