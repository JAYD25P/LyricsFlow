# LyricFlow — Android synced lyrics widget

LyricFlow is a native Android companion app and resizable home-screen lyrics widget. It follows the active Android media session, retrieves time-synchronised lyrics, and updates the widget as playback advances.

## Features

- Detects the active Android media session through Android Notification Listener access.
- Looks up timestamped lyrics through LRCLIB and caches retrieved `.lrc` files locally.
- Resizable Jetpack Glance home-screen widget with live current-line updates.
- Full-screen companion lyrics view with auto-scroll and selectable line animations.
- Original-script, Hinglish/Roman, and dual-script display modes.
- Backgrounds: Material You/system colours, solid colours, gradient presets, current album artwork, or a user-selected photo.
- Text controls: colour, highlight colour, font family, alignment, size, bold and italic.
- Widget controls: corner radius, surrounding lines, track metadata visibility, and sync offset.
- Offline display for lyrics already cached or imported.

## Build

Requirements:
- Android Studio with Android SDK Platform 35
- JDK 17
- Gradle 8.9 (the included GitHub Actions workflow installs it)

Open this folder in Android Studio and run `:app:assembleDebug`, or push the project to a GitHub repository and run **Actions → Build APK**. The workflow builds the debug APK, uploads `app-debug.apk` as the `LyricFlow-APK` workflow artifact, and publishes it as a downloadable GitHub Actions artifact.

## First-run setup

1. Install and open LyricFlow.
2. Open **Now playing** and grant Notification access to LyricFlow in Android Settings. This is required so Android can expose active media-session metadata and playback position.
3. Add the LyricFlow widget from your launcher's widget picker.
4. Start music in a supported player. When that player exposes an Android MediaSession, LyricFlow can identify the track and follow its playback position.

Some Android builds require the user to allow restricted settings for sideloaded apps before Notification access can be enabled.

## Language support and accuracy

The app preserves the lyrics' original script and offers a Hinglish/Roman rendering. Hindi-to-Latin conversion is rule-based, and other scripts use Android ICU transliteration where available. Romanisation is not a guarantee of native-speaker spelling or pronunciation. Lyrics availability depends on the selected provider and the specific recording; not every track has timestamped lyrics. The app does not translate the meaning of lyrics.

## Animation and widget behaviour

Compose animations (fade, slide, zoom, karaoke-style highlight, typewriter, and glow) run in the in-app companion view. Android launcher widgets are rendered as remote views and cannot run continuous custom Compose animations. The widget instead refreshes on playback/lyric-line changes, keeping the displayed line synchronised without pretending to animate inside the launcher.

## Permissions and privacy

- `INTERNET`: fetch lyrics from LRCLIB.
- Notification Listener access: read active media-session information exposed by Android.
- User-selected photo access is mediated by Android's system photo picker.

Track title, artist, album, and duration are sent to LRCLIB to look up matching lyrics. Cached lyric files and preferences are stored locally by the app. LyricFlow does not need a Spotify API key or a user account.

## Attribution

This project uses the open-source CarLyrics project as a functional reference:
https://github.com/mliem2k/carlyrics

Review the upstream repository's MIT licence and retain its attribution when reusing upstream code. The LyricFlow implementation in this project is a separate Android project; verify all third-party dependency and source licences before redistribution.

## Compatibility notes

- Minimum Android version: Android 8.0 (API 26).
- Media-session visibility and background behaviour vary by Android version, player app, and device manufacturer.
- The launcher controls widget refresh cadence and may delay redraws under battery optimisation.
